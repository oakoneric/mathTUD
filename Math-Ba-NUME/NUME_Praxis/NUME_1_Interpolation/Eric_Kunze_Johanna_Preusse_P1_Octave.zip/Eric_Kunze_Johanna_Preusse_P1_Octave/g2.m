% Eric_Kunze_Johanna_Preusse_P1_Octave

function y = g2( x )
  % Ableitung von g
  y=-pi*sin(1.5*pi*x)*(1+cos(1.5*pi*x))^(-1/3);
end

