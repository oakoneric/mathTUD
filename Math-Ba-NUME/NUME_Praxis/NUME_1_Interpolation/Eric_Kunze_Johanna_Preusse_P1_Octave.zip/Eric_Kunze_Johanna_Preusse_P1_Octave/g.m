% Eric_Kunze_Johanna_Preusse_P1_Octave

function y = g( x )
  % andere Funktion
  y=(1.+cos((3*pi/2).*x)).^(2/3); 
end

