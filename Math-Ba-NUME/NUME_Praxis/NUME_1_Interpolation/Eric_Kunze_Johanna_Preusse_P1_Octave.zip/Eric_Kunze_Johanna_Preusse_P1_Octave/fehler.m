% Eric_Kunze_Johanna_Preusse_P1_Octave

function y = fehler( f , spline )
  y=abs(f-spline);
end

