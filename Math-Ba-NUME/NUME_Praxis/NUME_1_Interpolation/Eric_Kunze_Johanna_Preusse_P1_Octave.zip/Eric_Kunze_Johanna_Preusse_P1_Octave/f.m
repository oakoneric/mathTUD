% Eric_Kunze_Johanna_Preusse_P1_Octave

function  y=f( x )
  %runge-funktion
  y = 1 ./ (1 + 25.*x.*x);
end

