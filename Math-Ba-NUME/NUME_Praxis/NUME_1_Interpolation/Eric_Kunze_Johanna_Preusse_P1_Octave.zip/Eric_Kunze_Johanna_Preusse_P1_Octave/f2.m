% Eric_Kunze_Johanna_Preusse_P1_Octave

function y =f2( x )
  % Ableitung von f
  y=-50*x/(1+50*x*x+625*x^4);
end

