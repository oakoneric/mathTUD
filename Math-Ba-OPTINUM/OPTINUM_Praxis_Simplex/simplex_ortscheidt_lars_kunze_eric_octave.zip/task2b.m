clear all
close all

% zweite Aufgabe - Teil (b):

A = [1,-1,-1,0 ; 2,0,-1,2 ; 3,-1,-2,-2 ; 4,2,-1,-1]; 
b = [-1,-1,2,6]'; 
c = [1,1,1,1]';