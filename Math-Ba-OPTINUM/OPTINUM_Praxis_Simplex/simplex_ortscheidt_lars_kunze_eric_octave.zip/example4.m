clear all
close all

%Test aus Uebung

A = [-1,2,1,0,0;2,2,0,1,0;1,-4,0,0,1];
b = [4;1;4];
c = [-2;1;0;0;0]; 