clear all
close all

%Test aus Uebung mit HZF

A = [4,1,-1,1,0 ; 1,1,-3,0,1 ; -1,2,-2,0,0]; 
b = [5;3;1]; 
c = [-1,-2,3,0,0]'; 