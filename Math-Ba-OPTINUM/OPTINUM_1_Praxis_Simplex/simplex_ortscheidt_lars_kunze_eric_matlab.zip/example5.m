clear all
close all

%Test aus Uebung

A = [2,-1,1,0,0;1,-3,0,1,0;1,0,0,0,1]; 
b = [10;15;4]; 
c = [1;-3;0;0;0]; 