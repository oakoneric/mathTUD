clear all
close all

% erste Aufgabe - Teil (a)

A = [1,-1,0,1 ; 1,-1,1,0 ; 2,0,-1,-1 ; -1,-1,1,2]; 
b = [2,-3,-1,3]'; 
c = [1,1,1,1]'; 