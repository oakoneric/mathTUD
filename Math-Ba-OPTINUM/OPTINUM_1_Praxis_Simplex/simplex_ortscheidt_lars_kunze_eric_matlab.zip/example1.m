clear all
close all

%Test aus Vorlesung

A = [1,2,1,0;4,1,0,1];
b = [6;10];
c = [-1;-1;0;0];  